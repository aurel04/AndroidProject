package com.aurel.aplikasigithubuser.data.model

data class UserResponse(
    val items: ArrayList<User>
)
